from __future__ import unicode_literals

# Vim command line buffer.
COMMAND_BUFFER = 'command-buffer'
